package cz.zweistein.df.soundsense.config.sounds;

public enum Loop {

	START_LOOPING,
	STOP_LOOPING;

}
