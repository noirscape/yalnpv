This is just a sample, in order to get actual sounds, look at 
http://df.zweistein.cz/soundsense/ for packs and install some.